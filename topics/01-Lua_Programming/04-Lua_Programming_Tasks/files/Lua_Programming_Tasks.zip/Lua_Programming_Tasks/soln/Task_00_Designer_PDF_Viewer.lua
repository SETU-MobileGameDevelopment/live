#!/usr/bin/env lua


-- Complete the designerPdfViewer function below.
local function designerPdfViewer(h, word)

end


-- i/o code 

local h = {}

for token in string.gmatch(io.stdin:read("*l"), "[^%s]+") do
    table.insert(h, tonumber(token))
end

local word = io.stdin:read("*l")

local result = designerPdfViewer(h, word)

print(result)

