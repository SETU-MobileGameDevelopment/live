

--
-- Complete the 'climbingLeaderboard' function below.
--
-- The function is expected to return an INTEGER_ARRAY.
-- The function accepts following parameters:
--  1. INTEGER_ARRAY scores
--  2. INTEGER_ARRAY player
--

local function climbingLeaderboard(scores, player)
    -- Write your code here
end


-- i/o code

local scorecount = io.stdin:read("*n", "*l")

local scores = {}

for token in string.gmatch(io.stdin:read("*l"):gsub("%s+$", ""), "[^%s]+") do
    table.insert(scores, tonumber(token))
end

local playercount = io.stdin:read("*n", "*l")

local player = {}

for token in string.gmatch(io.stdin:read("*l"):gsub("%s+$", ""), "[^%s]+") do
    table.insert(player, tonumber(token))
end

local result = climbingLeaderboard(scores, player)

print(table.concat(result, "\n"))

