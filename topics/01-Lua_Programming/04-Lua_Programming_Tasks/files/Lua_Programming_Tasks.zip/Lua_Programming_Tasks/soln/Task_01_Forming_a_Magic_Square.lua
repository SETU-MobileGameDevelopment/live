

-- Complete the formingMagicSquare function below.
local function formingMagicSquare(s)


end



-- i/o code 

local s = {}

for i = 1, 3 do
    s[i] = {}

    for token in string.gmatch(io.stdin:read("*l"), "[^%s]+") do
        table.insert(s[i], tonumber(token:match("(.-)%s*$")))
    end
end

local result = formingMagicSquare(s)

print(result)

